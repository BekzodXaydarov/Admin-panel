import React, { useState } from 'react';
import { Modal, Button, Group, Text } from '@mantine/core';
import {PlusIcon} from '../../assets/svgs/index'

export default function ModalComponent({btn_title,body,title}) {
  const [opened, setOpened] = useState(false);

  return (
    <>
      <Modal
        opened={opened}
        onClose={() => setOpened(false)}
        title={title}
      >
        {body}
      </Modal>

      <Group position="center">
        <Button onClick={() => setOpened(true)}>
          <PlusIcon fill="#fff"  />  <Text ml={"15px"}>{btn_title}</Text> 
        </Button>
      </Group>
    </>
  );
}