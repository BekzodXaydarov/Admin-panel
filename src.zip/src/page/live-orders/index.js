import { Title } from '@mantine/core'
import React from 'react'

export default function Live_Orders() {
  return (
    <div>
      <Title>Aktiv buyurtmalar</Title>

    </div>
  )
}
