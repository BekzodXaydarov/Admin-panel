import { Button, Text, Title, Table } from "@mantine/core";
import React, { useEffect } from "react";
import axios from "axios";
import { setRoom } from "../../redux/rooms";
import { useDispatch, useSelector } from "react-redux";
import Modal from "../../components/modal/modal";
import Form from "./form";

export default function Room() {
  const rooms = useSelector((room) => room.rooms);
  const rows = rooms.map((element) => (
    <Table.Tr key={element.name}>
      <Table.Td style={{ border: "1px solid black" }}>{element.id}</Table.Td>
      <Table.Td style={{ border: "1px solid black" }}>
        {element.room_type_name}
      </Table.Td>
      <Table.Td style={{ border: "1px solid black" }}>
        {element.places}
      </Table.Td>
      <Table.Td style={{ border: "1px solid black" }}>
        <Button color="red">O`chirish</Button>
      </Table.Td>
    </Table.Tr>
  ));
  const dispatch = useDispatch();
  const GetRoom = () => {
    let data = '';

    let config = {
      method: 'get',
      maxBodyLength: Infinity,
      url: 'https://epos-admin.dadabayev.uz/api/room/get',
      headers: { 
        'Content-Type': 'application/json', 
        'Accept': 'application/json', 
        'Authorization': 'Bearer Bearer 21|1wQQrOXLjbOAPaQRlBPb7mMAQVpxF10I6uiBJLZO567d04ec'
      },
      data : data
    };
    
    axios.request(config)
    .then(({data}) => {
        dispatch(setRoom(data?.result))
    })
    .catch((error) => {
      console.log(error);
    });
  };
  GetRoom();
  return (
    <div style={{ width: "75%" }}>
      <div
        className="room_header"
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "10px",
        }}
      >
        <Title>Xonalar/Stollar</Title>
        <Modal
          btn_title={"Yangi xona/stol qo`shish"}
          title={"Yangi xona/stol qo`shish"}
          body={
            <>
              <Form />
            </>
          }
        />
      </div>
      <div className="room_body" style={{ padding: "10px" }}>
        <Table striped highlightOnHover style={{ border: "1px solid black" }}>
          <Table.Thead>
            <Table.Tr style={{ border: "1px solid black" }}>
              <Table.Th style={{ border: "1px solid black" }}>
                <Text fw={600} fz={"17px"}>
                  Xona/Stol raqami
                </Text>
              </Table.Th>
              <Table.Th style={{ border: "1px solid black" }}>
                <Text fw={600} fz={"17px"}>
                  Status
                </Text>
              </Table.Th>
              <Table.Th style={{ border: "1px solid black" }}>
                <Text fw={600} fz={"17px"}>
                  Nechi kishilik
                </Text>
              </Table.Th>
              <Table.Th style={{ border: "1px solid black" }}>
                <Text fw={600} fz={"17px"}>
                  O'chirish
                </Text>
              </Table.Th>
            </Table.Tr>
          </Table.Thead>
          <Table.Tbody style={{ border: "1px solid black" }}>{rows}</Table.Tbody>
        </Table>
      </div>
    </div>
  );
}
