import { Button, NumberInput, Select } from "@mantine/core";
import React, { useState } from "react";

export default function Form() {
  const [id, setId] = useState(0);
  const [poeple, setPoeple] = useState(0);
  const [status, setStatus] = useState("");
  const onSubmit = () => {
    console.log(id);
    console.log(poeple);
    console.log(status);
  };
  return (
    <form onSubmit={(e) => e.preventDefault()}>
      <NumberInput
        defaultValue={0}
        placeholder="Xona/Stol raqami"
        label="Xona/Stol raqami"
        onChange={(e) => setId(e)}
        value={id}
      />
      <NumberInput
        mt={"15px"}
        defaultValue={0}
        placeholder="Nechi kishilik"
        label="Nechi kishilik"
        onChange={(e) => setPoeple(e)}
        value={poeple}
      />
      <Select
        mt={"15px"}
        data={[
          { value: "Xona", label: "Xona" },
          { value: "Stul", label: "Stul" },
        ]}
        placeholder="Joy Turi"
        label="Joy Turi"
        onChange={(e) => setStatus(e)}
      />
      <Button onClick={() => onSubmit()} color="blue" ml={"75%"} mt={"20px"}>
        Yuborish
      </Button>
    </form>
  );
}
